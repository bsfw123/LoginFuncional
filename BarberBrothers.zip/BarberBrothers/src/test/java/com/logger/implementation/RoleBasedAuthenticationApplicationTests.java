package com.logger.implementation;

import com.role.implementation.RoleBasedAuthenticationApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = RoleBasedAuthenticationApplication.class)
class RoleBasedAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
