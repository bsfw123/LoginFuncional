package com.role.implementation.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "servicio")
public class Servicio implements Serializable {

    // Asegura que 'idCita' se incremente automáticamente
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idCita;  // ID autoincrementable

    private String fechaHora;
    private String cliente;
    private String servicio;
    private String empleado;

    // Constructor vacío (requerido por JPA)
    public Servicio() {}

    // Constructor con parámetros para facilitar la creación de objetos
    public Servicio(Long idCita, String fechaHora, String cliente, String servicio, String empleado) {
        this.idCita = idCita;
        this.fechaHora = fechaHora;
        this.cliente = cliente;
        this.servicio = servicio;
        this.empleado = empleado;
    }

    // Getters y setters
    public Long getIdCita() {
        return idCita;
    }

    public void setIdCita(Long idCita) {
        this.idCita = idCita;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

    public String getEmpleado() {
        return empleado;
    }

    public void setEmpleado(String empleado) {
        this.empleado = empleado;
    }

    // Otros métodos (si es necesario) pueden ir aquí
}
