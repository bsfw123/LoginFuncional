/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.role.implementation.controller;

/**
 *
 * @author Asus
 */

import com.role.implementation.exception.ResourceNotFoundException;
import com.role.implementation.model.Empleado;
import com.role.implementation.service.EmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/tecnicos")
public class EmpleadoController {

    @Autowired
    private EmpleadoService empleadoService;

    // Mostrar lista de técnicos por defecto
@GetMapping
public String listarTecnicos(Model model) {
    model.addAttribute("tecnicos", empleadoService.listarTodas());
    return "tecnicos"; // El nombre de la vista Thymeleaf (tecnicos.html)
}


    // Mostrar formulario de agregar técnico
    @GetMapping("/add")
    public String mostrarFormularioAgregar(Model model) {
        model.addAttribute("empleado", new Empleado());
        return "tecnico-form"; // Vista para el formulario
    }

    // Guardar un nuevo técnico
    @PostMapping("/save")
    public String guardarTecnico(@ModelAttribute Empleado empleado) {
        empleadoService.guardar(empleado);
        return "redirect:/tecnicos";
    }

    // Mostrar formulario para editar un técnico
    @GetMapping("/edit/{IdCita}")
    public String mostrarFormularioEditar(@PathVariable Long IdCita, Model model) {
        Empleado empleado;
        empleado = empleadoService.obtenerPorId(IdCita);
        if (empleado == null) {
            throw new ResourceNotFoundException("Empleado no encontrado con ID " + IdCita);
        }
        model.addAttribute("empleado", empleado);
        return "tecnico-form";
    }

    // Eliminar técnico
    @GetMapping("/delete/{IdCita}")
    public String eliminarTecnico(@PathVariable Long IdCita) {
        empleadoService.eliminar(IdCita);
        return "redirect:/tecnicos";
    }
}
