/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.role.implementation.repository;

/**
 *
 * @author Asus
 */
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.role.implementation.model.Empleado;


@Repository
public interface EmpleadoRepository extends JpaRepository<Empleado, Long>{

	
}
