package com.role.implementation.controller;

import com.role.implementation.exception.ResourceNotFoundException;
import com.role.implementation.model.Servicio;
import com.role.implementation.service.ServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;

@Controller
@RequestMapping("/servicioA")
public class ServicioController {

    @Autowired
    private ServicioService servicioService;

    // Mostrar la lista de servicios en formato JSON
    @GetMapping
    @ResponseBody
    public List<Servicio> mostrarServicios() {
        return servicioService.listarTodos();
    }

    // Mostrar el formulario para agregar un servicio
    @GetMapping("/add")
    public String mostrarFormularioAgregar(Model model) {
        
        model.addAttribute("servicio", new Servicio());
        return "servicio-form"; // Vista del formulario para agregar servicio
    }

    // Guardar un nuevo servicio
    @PostMapping("/save")
    public String guardarServicio( @ModelAttribute Servicio servicio, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            // Si hay errores de validación, redirige al formulario con los errores
            return "servicio-form";
        }
        //no es necesario, idCita es auto-generado
        //if (servicio.getIdCita() == null) {
           // servicio.setIdCita(0L);  // O cualquier valor por defecto si es necesario
        //}
        servicioService.guardar(servicio);
        return "redirect:/adminScreen"; // Redirige a la lista de servicios después de guardar
    }

    // Mostrar el formulario para editar un servicio
    @GetMapping("/{idCita}/formularioEdit")
    public String mostrarFormularioEditar(@PathVariable("idCita") Long idCita, Model model) {
        Servicio servicio = servicioService.listarTodos()
                .stream()
                .filter(s -> s.getIdCita().equals(idCita))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Servicio no encontrado con ID " + idCita));
        model.addAttribute("servicio", servicio);
        return "servicio-formEdit"; // Vista reutilizada para editar el servicio
    }

    // Actualizar un servicio existente
    @PostMapping("/{idCita}/editservicio")
    public String actualizarServicio(@PathVariable("idCita") Long idCita, @ModelAttribute Servicio nuevoServicio) {
        servicioService.actualizar(idCita, nuevoServicio);
        return "redirect:/adminScreen"; // Redirige a la lista de servicios después de actualizar
    }

    // Eliminar un servicio por su ID
    // Eliminar un servicio por su ID
    @DeleteMapping("/{idCita}")
    @ResponseBody
    public ResponseEntity<String> eliminarServicio(@PathVariable("idCita") Long idCita) {
        try {
            servicioService.eliminar(idCita); // Lógica para eliminar el servicio
            return ResponseEntity.ok("Servicio eliminado exitosamente");
        } catch (ResourceNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se encontró el servicio con ID: " + idCita);
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Ocurrió un error al intentar eliminar el servicio");
        }
    }

}
