/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.role.implementation.service;

/**
 *
 * @author Asus
 */

import com.role.implementation.exception.ResourceNotFoundException;
import com.role.implementation.model.Servicio;
import com.role.implementation.repository.ServicioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioService {

    @Autowired
    private ServicioRepository repository;


    // Guardar un nuevo servicio
    public Servicio guardar(Servicio servicio) {
        return repository.save(servicio);
    }
    
    // Listar todos los servicios
    public List<Servicio> listarTodos() {
        return repository.findAll();
    }

    

    // Actualizar un servicio existente
    public Servicio actualizar(Long idCita, Servicio nuevoServicio) {
        return repository.findById(idCita).map(servicio -> {
            // Actualiza solo si el servicio existe
            servicio.setFechaHora(nuevoServicio.getFechaHora());
            servicio.setCliente(nuevoServicio.getCliente());
            servicio.setServicio(nuevoServicio.getServicio());
            servicio.setEmpleado(nuevoServicio.getEmpleado());
            return repository.save(servicio);
        }).orElseThrow(() -> new RuntimeException("No se encontró el servicio con ID: " + idCita));
    }

    // Eliminar un servicio por ID
    public void eliminar(Long idCita) {
    // Verificar si el servicio existe en la base de datos
    if (!repository.existsById(idCita)) {
        throw new ResourceNotFoundException("No se encontró el servicio con ID: " + idCita);
    }
    // Eliminar el servicio si existe
    repository.deleteById(idCita);
}

}


