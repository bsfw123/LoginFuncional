package com.role.implementation.DTO;

import java.time.LocalDateTime;

public class ServicioRegistradoDTO {

    private Long idCita;
    private String fechaHora; // Preferible a String
    private String cliente;
    private String servicio;
    private String empleado;

    // Constructor
    public ServicioRegistradoDTO(Long idCita, String fechaHora, String cliente, String servicio, String empleado) {
        this.idCita = idCita;
        this.fechaHora = fechaHora;
        this.cliente = cliente;
        this.servicio = servicio;
        this.empleado = empleado;
    }

    // Getters y Setters
    public Long getIdCita() {
        return idCita;
    }

    public void setIdCita(Long idCita) {
        this.idCita = idCita;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

    public String getEmpleado() {
        return empleado;
    }

    public void setEmpleado(String empleado) {
        this.empleado = empleado;
    }
}
