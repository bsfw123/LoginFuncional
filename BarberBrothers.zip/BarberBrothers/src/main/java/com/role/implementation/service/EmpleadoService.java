/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.role.implementation.service;

/**
 *
 * @author Asus
 */
import com.role.implementation.model.Empleado;
import com.role.implementation.repository.EmpleadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmpleadoService{
@Autowired
private EmpleadoRepository empleadoRepository;

public List<Empleado> listarTodas() {
	return empleadoRepository.findAll();
}

public Empleado guardar(Empleado empleado) {
	return empleadoRepository.save(empleado);
}

public Empleado obtenerPorId(Long IdCita) {
	return empleadoRepository.findById(IdCita).orElse(null);
}

public void eliminar(Long IdCita) {
	empleadoRepository.deleteById(IdCita);
	}
}
